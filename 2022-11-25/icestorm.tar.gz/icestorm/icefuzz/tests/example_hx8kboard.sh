#!/bin/bash
ICEDEV=hx8k-ct256 bash ../icecube.sh example_hx8kboard.v
