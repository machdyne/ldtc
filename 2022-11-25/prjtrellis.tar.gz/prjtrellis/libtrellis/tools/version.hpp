#ifndef VERSION_H
#define VERSION_H
#include <string>
extern const std::string git_describe_str;
#endif
