#include "Util.hpp"

namespace Trellis {
VerbosityLevel verbosity = VerbosityLevel::DEBUG;
}
