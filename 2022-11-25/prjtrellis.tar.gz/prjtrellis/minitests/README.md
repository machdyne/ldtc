### Minitests

There are also "minitests" which are designs which can be viewed by a human to
better understand how to generate more useful designs.
