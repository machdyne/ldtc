# ECP5 Evaluation Board Example

Run `make prog` to load the example to the board.

You must ensure JP2 is shorted to connect the 12MHz
FTDI clock to the FPGA.