# ECP5 Versa-5G Demo

Run `make prog` to build & load, LEDs will count and
a message will scroll on the 14-segment display.

If your Versa board is new, you will need to change
J50 to bypass the iSPclock. Re-arrange the jumpers
to connect pins 1-2 and 3-5 (leaving one jumper spare).
See p19 of the Versa Board user guide.
